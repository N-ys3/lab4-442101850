
from django.contrib import admin
from django.urls import path, include


urlpatterns = [
    path('admin/', admin.site.urls),
    path('tax/', include('taxes.urls'))

]



# Naaser alsaleh
# ID:442101850